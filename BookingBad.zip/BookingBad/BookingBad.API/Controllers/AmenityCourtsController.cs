﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Repositories;
using Repositories.DTO;
using Repositories.Entities;
using Services;

namespace BookingBad.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AmenityCourtsController : ControllerBase
    {
        private AmenityCourtServices services;

        public AmenityCourtsController()
        {
            services = new AmenityCourtServices();
        }


        // GET: api/AmenityCourts/5
        [HttpGet("{id}")]
        public async Task<ActionResult<IEnumerable<AmenityCourtDTO>>> GetAmenityCourt(int id)
        {
            var amenityCourt = services.GetAmenityByCourtId(id);

            if (amenityCourt == null)
            {
                return NotFound();
            }

            return amenityCourt;
        }

        // PUT: api/Courts/5/Amenities
        [HttpPut("{idCourt}")]
        public ActionResult UpdateCourtAmenities(int idCourt, [FromBody] List<int> amenityIds)
        {
            services.UpdateAmenityCourt(idCourt, amenityIds);
            return Ok();
        }

        // DELETE: api/AmenityCourts/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteAmenityCourt(int id)
        {
            var amenityCourt = services.GetAmenityByCourtId(id);
            if (amenityCourt == null)
            {
                return NotFound();
            }

            services.DeleteAmenityCourt(id);
            return NoContent();
        }
    }
}
