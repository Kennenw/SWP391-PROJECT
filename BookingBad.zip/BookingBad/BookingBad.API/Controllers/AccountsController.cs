﻿using Microsoft.AspNetCore.Mvc;
using Repositories.DTO;
using Services;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace BookingDemo.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AccountsController : ControllerBase
    {
        private readonly IAccountServices _accountServices;

        public AccountsController(IAccountServices accountServices)
        {
            _accountServices = accountServices;
        }

        // GET: api/Accounts
        [HttpGet]
        public async Task<ActionResult<IEnumerable<AccountDTO>>> GetAccounts()
        {
            var accounts = _accountServices.GetAccount();
            if (accounts == null)
            {
                return NotFound();
            }
            return Ok(accounts);
        }

        // GET: api/Accounts/5
        [HttpGet("{id}")]
        public async Task<ActionResult<AccountDTO>> GetAccount(int id)
        {
            var account = _accountServices.GetAccountById(id);
            if (account == null)
            {
                return NotFound();
            }

            return Ok(account);
        }

        // PUT: api/Accounts/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutAccount(int id, AccountDTO accountDTO)
        {
            _accountServices.UpdateAccount(id, accountDTO);
            return NoContent();
        }

        // POST: api/Accounts
        [HttpPost]
        public async Task<ActionResult<AccountDTO>> PostAccount(AccountDTO account)
        {
            _accountServices.CreateAccount(account);
            return CreatedAtAction("GetAccount", new { id = account.AccountId }, account);
        }

        // DELETE: api/Accounts/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteAccount(int id)
        {
            var account = _accountServices.GetAccountById(id);
            if (account == null)
            {
                return NotFound();
            }
            _accountServices.DeleteAccount(id);
            return NoContent();
        }

        // POST: api/Accounts/login
        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] LogInDTO model)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var result = await _accountServices.SignInAsync(model);

            if (string.IsNullOrEmpty(result) || result.Contains("thất bại"))
                return Unauthorized(new { message = "Đăng nhập thất bại: Email hoặc mật khẩu không đúng." });

            return Ok(new { message = result });
        }
    }
}
