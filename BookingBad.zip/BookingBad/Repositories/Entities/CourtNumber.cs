﻿using System;
using System.Collections.Generic;

namespace Repositories.Entities;

public partial class CourtNumber
{
    public int CourtNumberId { get; set; }

    public string? Description { get; set; }

    public int? CourtId { get; set; }

    public virtual Court? Court { get; set; }
    public virtual ICollection<Schedule> Schedules { get; set; } = new List<Schedule>();
}
