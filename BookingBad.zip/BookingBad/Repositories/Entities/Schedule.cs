﻿using System;
using System.Collections.Generic;

namespace Repositories.Entities;

public partial class Schedule
{
    public int ScheduleId { get; set; }

    public int? CourtNumberId { get; set; }

    public int? SlotId { get; set; }

    public virtual ICollection<BookingDetail> BookingDetails { get; set; } = new List<BookingDetail>();

    public virtual CourtNumber? CourtNumber { get; set; }

    public virtual SlotTime? Slot { get; set; }
}
