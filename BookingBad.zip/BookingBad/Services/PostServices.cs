﻿using Repositories;
using Repositories.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Services
{
    public interface IPostServices
    {
        public List<Post> GetPost();
        public Post GetPostById(int id);
        public void CreatePost(Post post);
        public void UpdatePost(int id, Post post);
        public void DeletePost(int id);
    }
    public class PostServices : IPostServices
    {
        private readonly UnitOfWork _unitOfWork;

        public PostServices()
        {
            _unitOfWork ??= new UnitOfWork();
        }
        public void CreatePost(Post post)
        {
            _unitOfWork.PostRepo.Create(post);
            _unitOfWork.SaveChanges();
        }

        public void DeletePost(int id)
        {
            var items = _unitOfWork.PostRepo.GetById(id);
            if(items != null)
            {
                _unitOfWork.PostRepo.Remove(items);
                _unitOfWork.SaveChanges();
            }
        }

        public List<Post> GetPost()
        {
            return _unitOfWork.PostRepo.GetAll();
        }

        public Post GetPostById(int id)
        {
            return _unitOfWork.PostRepo.GetById(id);
        }

        public void UpdatePost(int id, Post post)
        {
            _unitOfWork.PostRepo.Update(id, post);
            _unitOfWork.SaveChanges();
        }
    }
}
