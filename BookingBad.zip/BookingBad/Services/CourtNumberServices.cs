﻿using Repositories;
using Repositories.DTO;
using Repositories.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Services
{
    public interface ICourtNumberServices
    {
        public void GetCourtNumberActives(int id);

        public List<CourtNumberDTO> courtNumbers(int id);

        public CourtNumberDTO CreateCourtNumber(CourtNumberDTO courtNumber);


    }
    public class CourtNumberServices : ICourtNumberServices
    {
        private readonly UnitOfWork _unitOfWork;

        public CourtNumberServices()
        {
            _unitOfWork ??= new UnitOfWork();
        }

        public List<CourtNumberDTO> courtNumbers(int id)
        {
            return _unitOfWork.CourtNumberRepo.GetCourtNumber(id).Select(courtNs => new CourtNumberDTO
            {
                CourtId = courtNs.CourtId,
                Description = courtNs.Description,
                CourtNumberId = courtNs.CourtNumberId,
            }).ToList();
        }

        public CourtNumberDTO CreateCourtNumber(CourtNumberDTO courtNumber)
        {
            throw new NotImplementedException();
        }

        public void GetCourtNumberActives(int id)
        {
            throw new NotImplementedException();
        }
    }
}
