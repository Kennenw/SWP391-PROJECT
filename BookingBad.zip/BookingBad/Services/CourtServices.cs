﻿using Repositories;
using Repositories.DTO;
using Repositories.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Services
{
    public interface ICourtServices
    {
        public List<CourtDTO> GetCourt();
        public CourtDTO GetCourtById(int id);
        public void CreateCourt(CourtDTO courtDTO);
        public void UpdateCourt(int id, CourtDTO courtDTO);
        public void DeleteCourt(int id);

    }
    public class CourtServices : ICourtServices
    {
        private readonly UnitOfWork _unitOfWork;

        public CourtServices()
        {
            _unitOfWork ??= new UnitOfWork();
        }



        public void CreateCourt(CourtDTO courtDTO)
        {
            Court court = new Court
            {
                AreaId = courtDTO.AreaId,
                CourtName = courtDTO.CourtName,
                OpenTime = courtDTO.OpenTime,
                CloseTime = courtDTO.CloseTime,
                Rule =  courtDTO.Rule,
                Status = courtDTO.Status,
            };
            _unitOfWork.CourtRepo.Create(court);
            _unitOfWork.SaveChanges();
        }

        public void DeleteCourt(int id)
        {
            var court = _unitOfWork.CourtRepo.GetById(id);
            if(court != null)
            {
                court.Status = false;
                _unitOfWork.CourtRepo.Update(court);
                _unitOfWork.SaveChanges();
            }
        }

        public List<CourtDTO> GetCourt()
        {
            return _unitOfWork.CourtRepo.GetAll().Select(court => new CourtDTO {
                CourtId = court.CourtId,
                AreaId = court.AreaId,
                CourtName = court.CourtName,
                OpenTime = court.OpenTime,
                CloseTime = court.CloseTime,
                Rule = court.Rule,
                Status = court.Status,
            }).ToList();
        }
        
        public CourtDTO GetCourtById(int id)
        {
            var court = _unitOfWork.CourtRepo.GetById(id);
            return new CourtDTO
            {
                CourtId = court.CourtId,
                AreaId = court.AreaId,
                CourtName = court.CourtName,
                OpenTime = court.OpenTime,
                CloseTime = court.CloseTime,
                Rule = court.Rule,
                Status = court.Status,
            };
            
        }       

        public void UpdateCourt(int id, CourtDTO courtDTO)
        {
            var court = _unitOfWork.CourtRepo.GetById(id);
            if(court != null)
            {
                court.AreaId = courtDTO.AreaId;
                court.CourtName = courtDTO.CourtName;
                court.OpenTime = courtDTO.OpenTime;
                court.CloseTime = courtDTO.CloseTime;
                court.Rule = courtDTO.Rule;
                court.Status = courtDTO.Status;
                _unitOfWork.CourtRepo.Update(court);
                _unitOfWork.SaveChanges();
            }
        }
    }
}
