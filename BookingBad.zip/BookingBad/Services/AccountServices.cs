﻿using Repositories;
using Repositories.DTO;
using Repositories.Entities;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Services
{
    public interface IAccountServices
    {
        List<AccountDTO> GetAccount();
        AccountDTO GetAccountById(int id);
        AccountDTO GetAccountByName(string name);
        void CreateAccount(AccountDTO account);
        void UpdateAccount(int id, AccountDTO account);
        void DeleteAccount(int id);
        Task<string> SignInAsync(LogInDTO model);
    }

    public class AccountServices : IAccountServices
    {
        private readonly UnitOfWork _unitOfWork;

        public AccountServices()
        {
            _unitOfWork ??= new UnitOfWork();
        }

        public List<AccountDTO> GetAccount()
        {
            return _unitOfWork.AccountRepo.GetAll().
                Select(account => new AccountDTO
                {
                    AccountId = account.AccountId,
                    AccountName = account.AccountName,
                    Password = account.Password,
                    FullName = account.FullName,
                    Phone = account.Phone,
                    Email = account.Email,
                    RoleId = account.RoleId,
                    Status = account.Status,
                }).ToList();
        }

        public AccountDTO GetAccountById(int id)
        {
            var account = _unitOfWork.AccountRepo.GetById(id);
            if (account == null) return null;
            return new AccountDTO
            {
                AccountId = account.AccountId,
                AccountName = account.AccountName,
                Password = account.Password,
                FullName = account.FullName,
                Phone = account.Phone,
                Email = account.Email,
                RoleId = account.RoleId,
                Status = account.Status,
            };
        }

        public AccountDTO GetAccountByName(string name)
        {
            var account = _unitOfWork.AccountRepo.GetByName(name);
            if (account == null) return null;
            return new AccountDTO
            {
                AccountId = account.AccountId,
                AccountName = account.AccountName,
                Password = account.Password,
                FullName = account.FullName,
                Phone = account.Phone,
                Email = account.Email,
                RoleId = account.RoleId,
                Status = account.Status,
            };
        }

        public void UpdateAccount(int id, AccountDTO accountDTO)
        {
            var account = _unitOfWork.AccountRepo.GetById(id);
            if (account != null)
            {
                account.AccountName = accountDTO.AccountName;
                account.Password = accountDTO.Password;
                account.FullName = accountDTO.FullName;
                account.Phone = accountDTO.Phone;
                account.Email = accountDTO.Email;
                account.RoleId = accountDTO.RoleId;
                account.Status = accountDTO.Status;
                _unitOfWork.AccountRepo.Update(account);
                _unitOfWork.SaveChanges();
            }
        }

        public void DeleteAccount(int id)
        {
            var account = _unitOfWork.AccountRepo.GetById(id);
            if (account != null)
            {
                _unitOfWork.AccountRepo.Remove(account);
                _unitOfWork.SaveChanges();
            }
        }

        public void CreateAccount(AccountDTO accountDTO)
        {
            var account = new Account
            {
                AccountName = accountDTO.AccountName,
                Password = accountDTO.Password,
                FullName = accountDTO.FullName,
                Phone = accountDTO.Phone,
                Email = accountDTO.Email,
                RoleId = accountDTO.RoleId,
                Status = accountDTO.Status,
            };
            _unitOfWork.AccountRepo.Create(account);
            _unitOfWork.SaveChanges();
        }

        public async Task<string> SignInAsync(LogInDTO model)
        {
            var account = _unitOfWork.AccountRepo.GetAccountByEmailAndPassword(model.Email, model.Password);

            if (account == null)
            {
                return "Đăng nhập thất bại: Email hoặc mật khẩu không đúng.";
            }

            return "Đăng nhập thành công!";
        }
    }
}
