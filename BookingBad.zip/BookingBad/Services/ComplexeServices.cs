﻿using Repositories;
using Repositories.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Services
{

    public interface IComplexeServices
    {
        public List<Complexe> GetComplexe();
        public Complexe GetComplexeById(int id);
        public void CreateComplexe(Complexe complexe);
        public void UpdateComplexe(int id, Complexe complexe);
        public void DeleteComplexe(int id);
    }
    public class ComplexeServices : IComplexeServices
    {
        private readonly UnitOfWork _unitOfWork;

        public ComplexeServices()
        {
            _unitOfWork ??= new UnitOfWork();
        }
        public void CreateComplexe(Complexe complexe)
        {
            _unitOfWork.complexeRepo.Create(complexe);
            _unitOfWork.SaveChanges();
        }

        public void DeleteComplexe(int id)
        {
            var items = _unitOfWork.complexeRepo.GetById(id);
            if (items != null)
            {
                _unitOfWork.complexeRepo.Remove(items);
                _unitOfWork.SaveChanges();
            }
        }
        public List<Complexe> GetComplexe()
        {
            return _unitOfWork.complexeRepo.GetAll();
        }

        public Complexe GetComplexeById(int id)
        {
            return _unitOfWork.complexeRepo.GetById(id);
        }

        public void UpdateComplexe(int id, Complexe complexe)
        {
            _unitOfWork.complexeRepo.Update(id,complexe);
            _unitOfWork.SaveChanges();
        }
    }
}
